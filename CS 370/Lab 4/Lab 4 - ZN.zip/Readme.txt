Name: Zachary Neeley
Project: Lab 4 Calculator SymbolTable
Description: For this lab I was able to complete all the needed requirements for this lab.
			 I was able to get all the error messaged to apear when needed. The YACC and LEX
			 files got the needed changes and additions for have the symbol table to work with
			 the calculator program.